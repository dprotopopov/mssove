#include <iostream>

int jacobi_field(int n,int *m,int *x,double value,int mode);
int indexOf(int *x, int *m, int n);
int *vectorOf(int index, int *x, int *m, int n);

